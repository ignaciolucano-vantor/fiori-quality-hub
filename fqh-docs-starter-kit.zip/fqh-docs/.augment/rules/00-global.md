# Global Rules

- Keep changes small and scoped.
- Do not change architecture without updating docs.
- Do not introduce new frameworks without explicit approval.
- Always update contracts when request or response shapes change.
- Always add test notes for new capabilities.
- Prefer reusable modules over app-specific duplication.
