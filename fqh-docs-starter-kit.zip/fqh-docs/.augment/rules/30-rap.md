# RAP Rules

- Build tables before CDS.
- Build CDS before behavior definitions.
- Use managed RAP non-draft for MVP1 unless a validated need appears.
- Keep one central service domain.
- Expose only MVP1 entities and actions.
- Keep Jira integration server-side.
