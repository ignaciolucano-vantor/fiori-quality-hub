# Jira Integration Rules

- Do not store secrets in application tables.
- Generate Jira payloads on the backend.
- Frontend only triggers actions and shows results.
- Support normal Jira issue creation and JSM request creation as separate modes.
- Do not implement bi-directional synchronization in MVP1.
