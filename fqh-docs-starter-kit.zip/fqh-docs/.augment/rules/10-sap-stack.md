# SAP Stack Rules

- Implementation must align with SAP_BASIS 756 SP02, SAP_ABA 75G SP02, SAP_GWFND 756 SP02, and SAP_UI 756 SP03.
- Stay within BASIS, ABAP, Fiori, CDS, FI, MM, and GTS scope.
- Use RAP patterns compatible with the target release.
- Avoid release assumptions that are not confirmed in documentation or validated in the system.
- Keep Payment Request logic outside this framework.
